### 231104(정하솔)

- html/css - 마크업 작업 1차 
- html/css - 크롬 브라우저에서 모바일 모드로 확인하면서 style 작업을 하는데 다른 페이지에서 주었던 값과 같은 width값을 주었지만 이 페이지만 모바일 모드에서 콘텐츠의 크기들이 엄청 작게 보이는 현상 발생함
  => 이유: html head에 <meta name="viewport" content="width=device-width, initial-scale=1.0"> 이 태그를 누락해서 발생한 일
- css - 서브페이지 title이 svg 이미지라서 가운데 정렬을 <svg viewbox="">로 각각 조절

### 231105(정하솔)

- html/css - 마크업 2차
- 미디어쿼리 작업 완성
- js - '프로젝트 문의하기' 누르면 contact 페이지로 이동까지 함(미완성)
  => 페이지 이동 후 '프로젝트 문의하기' toggle창이 자동으로 열리게 해야 됨
- js - '브로슈어 신청하기' 누르면 모달창 띄우기
